<?php

require __DIR__ . '/whatsapp_msg_send.php';

unlink( __DIR__ . '/whatsapp_token.json' );

echo send_whatsapp_message_google_sheet( '972552243820', 'this is :  test message' );

?>