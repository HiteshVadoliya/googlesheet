<?php

require __DIR__ . '/SpreadsheetSnippets.php';
require __DIR__ . '/vendor/autoload.php';

error_reporting(1);

function getClient()
{
    $client = new Google_Client();
    $client->setApplicationName('Google Sheets API PHP Quickstart');
    $client->setScopes(Google_Service_Sheets::SPREADSHEETS);
    $client->setAuthConfig(__DIR__ . '/whatsapp_credentials.json');
    $client->setAccessType('offline');
    $client->setPrompt('select_account consent');
    $tokenPath = __DIR__ . '/whatsapp_token.json';

    if( isset($_REQUEST['code']) && !empty($_REQUEST['code']) ) {
        $accessToken = $client->fetchAccessTokenWithAuthCode($_REQUEST['code']);
        $client->setAccessToken($accessToken);
        $file_content = json_encode($client->getAccessToken());
        
        $file = fopen($tokenPath, "w") or die("can't open file");
        fwrite($file, $file_content);
        fclose($file);
    }

    // Load previously authorized token from a file, if it exists.
    if (file_exists($tokenPath)) {
        $accessToken = json_decode(file_get_contents($tokenPath), true);
        $client->setAccessToken($accessToken);
    }


    // If there is no previous token or it's expired.
    if ($client->isAccessTokenExpired()) {
        if ($client->getRefreshToken()) {
            $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
            $file_content = json_encode($client->getAccessToken());
            $file = fopen($tokenPath, "w") or die("can't open file");
            fwrite($file, $file_content);
            fclose($file);

            $accessToken = json_decode(file_get_contents($tokenPath), true);
            $client->setAccessToken($accessToken);
        } else {
            $authUrl = urldecode( $client->createAuthUrl() );
            echo '<script>location.href="'.$authUrl.'";</script>';
            header('Location: ' . $authUrl);
            exit;
        }
    }
    return $client;
}

function filterVal( $val ) {
    // $val = str_replace(":", "-", $val);
    // $val = str_replace('"', "", $val);
    // $val = utf8_encode($val);
    return $val;
}

function send_whatsapp_message_google_sheet( $number, $message ) {
    if( !empty($number) && !empty($message) ) {
        
        if( function_exists('get_whatsapp_footer') ) {
            $message.= PHP_EOL.get_whatsapp_footer();  
        }

        if( substr( $number, 0, 3 ) != 972 ) {
            $number = '972'.substr($number, 1);
        }
        // make action magic happen here...    https://docs.google.com/spreadsheets/d/1qYjwY3fu2B091LFiZwAQtcukvgu-sPkykhLodIEvQCw/edit#gid=0
        $client = getClient();
        $service = new Google_Service_Sheets($client);
        $SpreadsheetSnippets = New SpreadsheetSnippets($service);
        $spreadsheetId = '1qYjwY3fu2B091LFiZwAQtcukvgu-sPkykhLodIEvQCw'; 

        // fetch all excel sheet
        $sheetInfo = $service->spreadsheets->get($spreadsheetId);
        $allsheet = (isset($sheetInfo['sheets'])) ? array_column($sheetInfo['sheets'], 'properties') : array();

        // fetch last sheet name
        $sheetname = '';
        foreach ($allsheet as $key => $value) {
            $sheetname = $value->title;
        }

        // Get product category and add order to that category sheet.
        $sheetdata = array();
        $sheetdata[] = array( $number, $message );
        $SpreadsheetSnippets->appendValues( $spreadsheetId, $sheetname, 'USER_ENTERED', $sheetdata );
        
        return true;

    } else {
        return 'number Or message is empty';
    }
}

if( isset($_REQUEST['code']) && !empty($_REQUEST['code']) && isset($_REQUEST['scope']) && !empty($_REQUEST['scope']) ) {
    echo send_whatsapp_message_google_sheet( '972552243820', 'this is :  test message' );
}
?>
