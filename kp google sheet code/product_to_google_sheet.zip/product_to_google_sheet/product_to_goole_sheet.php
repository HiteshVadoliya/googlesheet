<?php

require __DIR__ . '/SpreadsheetSnippets.php';
require __DIR__ . '/vendor/autoload.php';

error_reporting(1);

function myArrayContainsWord(array $myArray, $word) {
    foreach ($myArray as $element) {
        if ($element->title == $word) {
            return true;
        }
    }
    return false;
}

function getClient()
{
    $client = new Google_Client();
    $client->setApplicationName('Google Sheets API PHP Quickstart');
    $client->setScopes(Google_Service_Sheets::SPREADSHEETS);
    $client->setAuthConfig(__DIR__ . '/credentials.json');
    $client->setAccessType('offline');
    $client->setPrompt('select_account consent');
    $tokenPath = __DIR__ . '/token.json';

    if( isset($_REQUEST['code']) && !empty($_REQUEST['code']) ) {
        $accessToken = $client->fetchAccessTokenWithAuthCode($_REQUEST['code']);
        $client->setAccessToken($accessToken);
        $file_content = json_encode($client->getAccessToken());
        
        $file = fopen($tokenPath, "w") or die("can't open file");
        fwrite($file, $file_content);
        fclose($file);
    }

    // Load previously authorized token from a file, if it exists.
    if (file_exists($tokenPath)) {
        $accessToken = json_decode(file_get_contents($tokenPath), true);
        $client->setAccessToken($accessToken);
    }

    // If there is no previous token or it's expired.
    if ($client->isAccessTokenExpired()) {
        if ($client->getRefreshToken()) {
            $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
            $file_content = json_encode($client->getAccessToken());
            $file = fopen($tokenPath, "w") or die("can't open file");
            fwrite($file, $file_content);
            fclose($file);
        } else {
            $authUrl = urldecode( $client->createAuthUrl() );
            echo '<script>location.href="'.$authUrl.'";</script>';
            header('Location: ' . $authUrl);
            exit;
        }
    }
    return $client;
}

//get json array and return the item picture
function getItemPic($Gallery){
	$Pic 		 = "https://cdn4.iconfinder.com/data/icons/miu/22/editor_image_picture_photo-128.png";
	if($Gallery != ""):
		$array = json_decode($Gallery);
		$i = 0;
		foreach($array as $key=>$value):
			$i++;
			$max = $key;
			if($i == 1)
				break;
		endforeach;
	endif;
	$Pic  = "https://www.idanvip.com/images/files/thumbnail/".$max;
	return $Pic;
}

function filterVal( $val ) {
    // $val = str_replace(":", "-", $val);
    // $val = str_replace('"', "", $val);
    // $val = utf8_encode($val);
    return $val;
}


// make action magic happen here...    https://docs.google.com/spreadsheets/d/1LSLJTxamIekcCuf79qy5FVh3yiuKbDj5UMRXKNb4_vM/edit?ts=603d2d18#gid=0
$client = getClient();
$service = new Google_Service_Sheets($client);
$SpreadsheetSnippets = New SpreadsheetSnippets($service);
$spreadsheetId = '1vuvok0LGL8-35aA_UfCrPHiQV7kmjeSTmsiOwScpDNc'; 

// fetch all excel sheet
$sheetInfo = $service->spreadsheets->get($spreadsheetId);
$allsheet = (isset($sheetInfo['sheets'])) ? array_column($sheetInfo['sheets'], 'properties') : array();

// fetch last sheet name
$sheetname = '';
foreach ($allsheet as $key => $value) {
    $sheetname = $value->title;
}

// fetch sheet all velues
$sheetData = array();
$sheetBatchGet = $SpreadsheetSnippets->batchGetValues( $spreadsheetId, $sheetname );
if( !empty( $sheetBatchGet->valueRanges ) ) {
    foreach( $sheetBatchGet->valueRanges as $valueRange ) {
        $sheetData = !empty($valueRange->values) ? $valueRange->values : array();
    }
}

// echo "<pre>";
// print_r($sheetData);
// die;

require __DIR__ . '/../website/global/system/mysql.php';
$product_result = mysql_query( "SELECT * FROM `Items` where IsDeleted = 0 AND Temp = 0 AND ParentItemID = 0 AND IsSubProduct = 0 AND BuyPrice !='' AND WebsiteBuyName != '' AND WebsiteBuyIsShow = 1 Order by ID" );
if( mysql_num_rows($product_result) > 0 ) {
    $sheet_productIds = array_column($sheetData, 0);
    while($product = mysql_fetch_array($product_result) ) {
        $id = $product['ID'];
        
        $stock = 0;
        $order_items = mysql_query( "SELECT t1.ID FROM SubItems t1 JOIN ItemsPerOrder t2 ON t1.ID = t2.SubItemID Where t1.ItemID=$id AND t1.Type=1 AND t1.IsDeleted = 0 AND t2.Save=1" );
        $item_arr = array();
        if(mysql_num_rows($order_items) > 0) {
            while( $item_ID = mysql_fetch_array($order_items) ) {
                $item_arr[] = $item_ID['ID'];
            }
        }
        
        if( !empty($item_arr) ) {
            $item_ids = !empty($item_arr) ? implode(',', $item_arr) : '';
            $c5 = mysql_query( "SELECT ID FROM SubItems WHERE ID NOT IN ( $item_ids ) AND ItemID = $id AND IsDeleted = 0 AND Status = 0 AND Availability = 0 AND Type = 1" );
    		$stock = mysql_num_rows($c5);
        } else {
            $c5 = mysql_query( "SELECT ID FROM SubItems WHERE ItemID = $id AND IsDeleted = 0 AND Status = 0 AND Availability = 0 AND Type = 1" );
    		$stock = mysql_num_rows($c5);
        }
		
        $productID      = filterVal( 'idan'.$id );
        $Name           = filterVal( $product['WebsiteBuyName'] );
        $Description    = filterVal( strip_tags( $product['WebsiteBuyDescLong'] ) );
        $url            = filterVal( 'https://www.idanvip.co.il/buy/'.$product['ID'] );
        $New            = filterVal( 'New' );
        $BuyPrice       = filterVal( $product['BuyPrice'] );
        $BuyPriceHigh   = filterVal( $product['BuyPriceHigh'] );
        $inStock        = filterVal( ($stock > 0) ? 'In Stock' : 'Out of Stock' ); 
        $image          = filterVal( getItemPic($product['Gallery']) );
        $GoogleSheetBrand= filterVal( (!empty( $product['GoogleSheetBrand'])) ? $product['GoogleSheetBrand'] : 'IDAN VIP LTD' );
        
        $productData = array();
        if( in_array('idan'.$product['ID'], $sheet_productIds) ) {
            // update data
            $key = array_search ('idan'.$product['ID'], $sheet_productIds);
            $sheetData[$key][0] = $productID;
            $sheetData[$key][1] = $Name;
            $sheetData[$key][2] = $Description;
            $sheetData[$key][3] = $url;
            $sheetData[$key][4] = $New;
            $sheetData[$key][5] = $BuyPrice;
            $sheetData[$key][6] = !empty( $BuyPriceHigh ) ? $BuyPriceHigh : $BuyPrice;
            $sheetData[$key][7] = $inStock;
            $sheetData[$key][8] = $image;
            $sheetData[$key][9] = '';
            $sheetData[$key][10] = '';
            $sheetData[$key][11] = $GoogleSheetBrand;
        } else {
            // add new records 
            $rowData = array(
                $productID,
                $Name,
                $Description,
                $url,
                $New,
                $BuyPrice,
                ( !empty( $BuyPriceHigh ) ? $BuyPriceHigh : $BuyPrice ),
                $inStock,
                $image,
                '',
                '',
                $GoogleSheetBrand
            );
            // $rowData[11] = $GoogleSheetBrand;
            $sheetData[] = $rowData;
        }
    }
}

// echo "<pre>";
// echo json_encode($sheetData);

$SpreadsheetSnippets->batchUpdateValues( $spreadsheetId, $sheetname, 'USER_ENTERED', $sheetData );

       
?>
