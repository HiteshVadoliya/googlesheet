<?php

require __DIR__ . '/whatsapp_msg_send.php';

echo send_whatsapp_message_google_sheet( '972552243820', 'Test daily message date: '.date('d-m-Y') );

?>